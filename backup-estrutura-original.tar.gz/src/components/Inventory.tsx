import { InventoryNew } from './InventoryNew';

export const Inventory = () => {
  return <InventoryNew />;
};