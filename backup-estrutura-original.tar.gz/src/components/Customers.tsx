import { CustomersNew } from './CustomersNew';

export const Customers = () => {
  return <CustomersNew />;
};