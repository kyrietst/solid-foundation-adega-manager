"use client";

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AccordionSection {
  id: string;
  title: string;
  icon?: React.ReactNode;
  content: React.ReactNode;
  defaultOpen?: boolean;
  badge?: string | number;
}

interface PageAccordionProps {
  sections: AccordionSection[];
  className?: string;
  allowMultiple?: boolean;
}

export const PageAccordion: React.FC<PageAccordionProps> = ({
  sections,
  className,
  allowMultiple = true,
}) => {
  const [openSections, setOpenSections] = useState<Set<string>>(
    new Set(sections.filter(s => s.defaultOpen).map(s => s.id))
  );

  const toggleSection = (sectionId: string) => {
    setOpenSections(prev => {
      const newSet = new Set(prev);
      
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        if (!allowMultiple) {
          newSet.clear();
        }
        newSet.add(sectionId);
      }
      
      return newSet;
    });
  };

  return (
    <div className={cn("space-y-4 h-full overflow-y-auto", className)}>
      {sections.map((section) => {
        const isOpen = openSections.has(section.id);
        
        return (
          <Card key={section.id} className="border border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {section.icon && (
                    <div className="text-primary">
                      {section.icon}
                    </div>
                  )}
                  <CardTitle className="text-lg font-semibold">
                    {section.title}
                  </CardTitle>
                  {section.badge && (
                    <span className="ml-2 px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
                      {section.badge}
                    </span>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleSection(section.id)}
                  className="p-1 h-8 w-8"
                >
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </CardHeader>
            
            {isOpen && (
              <CardContent className="pt-0">
                <div className="space-y-4">
                  {section.content}
                </div>
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
};