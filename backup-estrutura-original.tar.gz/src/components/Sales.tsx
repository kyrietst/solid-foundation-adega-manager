import { SalesPage } from './sales/SalesPage';

export const Sales = () => {
  return <SalesPage />;
};
